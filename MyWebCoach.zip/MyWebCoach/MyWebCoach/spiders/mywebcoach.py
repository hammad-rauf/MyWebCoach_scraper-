from scrapy import Request
from scrapy.spiders import CrawlSpider, Rule
from scrapy.linkextractors import LinkExtractor

from ..items import MywebcoachItem

class MywebcoachSpider(CrawlSpider):

    name = "mywebcoach"
    
    img_link = "http://web.mycoachmatch.com/"

    def __init__(self, config_file = None, *args, **kwargs):                    
        super(MywebcoachSpider, self).__init__(*args, **kwargs)   

        file = open("mywebcoach.txt","r")

        links = []

        for link in file.readlines():
            links.append(link)
    
        self._url_list = links

        file.close()                                                             

    def start_requests(self):    

        for url in self._url_list:                                              
            yield Request(url = url, callback = self.parse)
   
    def parse(self, response):

        coach = MywebcoachItem()

        coach["name"] = response.css("td[valign='top']  .box h2 span::text").extract()
        coach["name"] = " ".join(coach["name"])

        coach["profession"] = response.css(".title_table .label::text").extract_first()

        coach["description"] = response.css(".maincontent_inner h1::text").extract_first()

        coach["city"] = coach["description"].split(" in ")[1]
        coach["city"] = coach["city"].split(",")[0]

        coach["country"] = coach["description"].split(", ")[1]

        coach["phone"] = response.css("div#ctl00_PageContainer_divPhoneNumber::text").extract_first()

        address = []
        for count in range(1,10):
            temp = response.css(f"span#ctl00_PageContainer_lblOffice{count}::text").extract()

            if not temp:
                break

            temp = " ".join(temp)

            address.append(temp)

        coach["address"] = address

        coach["url"] = response.url

        coach["website"] = response.css("#ctl00_PageContainer_lnkWebsite::text").extract_first()

        coach["aboutme"] = response.css("#ctl00_PageContainer_lblAboutMe::text").extract_first()

        coach["iamalso"] = response.css("#ctl00_PageContainer_dlProfessions li::text").extract()

        coach["concerIssueIDeal"] = response.css("#ctl00_PageContainer_dlConcerns li::text").extract()

        coach["ageIWorkWith"] = response.css("#ctl00_PageContainer_dlAges li::text").extract()

        coach["languagesISpeak"] = response.css("#ctl00_PageContainer_dlLanguages li::text").extract()

        coach["myFeeRange"] = response.css("#ctl00_PageContainer_dlFeeRanges li::text").extract()

        coach["image"] = response.css("#ctl00_PageContainer_imgTherapist::attr(src)").extract_first()

        temp = self.img_link

        coach["image"] = temp + coach["image"]

        yield coach