# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class MywebcoachItem(scrapy.Item):

    name = scrapy.Field()
    profession = scrapy.Field()
    description = scrapy.Field()

    city = scrapy.Field()
    country = scrapy.Field()
    address = scrapy.Field()

    phone = scrapy.Field()

    website = scrapy.Field()
    url = scrapy.Field()

    aboutme = scrapy.Field()

    iamalso = scrapy.Field()

    concerIssueIDeal = scrapy.Field()

    ageIWorkWith = scrapy.Field()

    languagesISpeak = scrapy.Field()

    myFeeRange = scrapy.Field()

    image = scrapy.Field()

    pass
